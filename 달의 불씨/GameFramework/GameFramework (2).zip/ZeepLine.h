#pragma once
#include "ISceneNode.h"
#include "Physical.h"
#include "Sprite.h"
#include "Pole.h"
class ZeepLine:virtual public ISceneNode,virtual public Physical 
{
private:
	Pole *m_pPole1;
	Pole *m_pPole2;
public:
	ZeepLine();
	~ZeepLine();
	
	void Render();

	void SetPole(Pole *p1, Pole *p2);
};

